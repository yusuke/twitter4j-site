package twitter4j;

/**
 * A data class represents search query.
 */
public class Query {
}
