package twitter4j;

public class TwitterBasicAuthTest extends TwitterTestUnit {
    public TwitterBasicAuthTest(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
    }

}
